
package tutti;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import tutifruti.RmiServerIntf;

/**
 *
 * @author lino
 */
            public class Tutti {

                /**
                 * @param args the command line arguments
                 */
                 public static String IPREMOTO = "//jmonetti.ddns.net:1099/RmiServer";
                static RmiServerIntf obj = null;
               public static void main(String[] args) {
                    
                    try {
                        System.out.println("TUTI FRUTI 3000 by Lino ;)");
                        CSVWriter.escribirManualmente();
                        if (System.getSecurityManager() == null) {
                            System.setProperty("java.security.policy", "java.policy");
                            System.setSecurityManager(new RMISecurityManager());
                        }
                        obj = (RmiServerIntf) Naming.lookup(IPREMOTO);
                        String quien="rallol";
                        String clave="basquet8";
                        String[] arrayCategorias = {"pais","frutaverdura","ciudad","cosa","deporte","nombremasculino","nombrefemenino","vegetal","accion","cantante"};

                        System.out.println(obj.comenzarComunicacion( quien,  clave));
                        String categorias = obj.getCategorias( quien,  clave);
                        System.out.println(categorias);
                        for(int i=0; i<=0 ;i++ ){
                            System.out.println("  -  iteracion="+i);
                            String letra =obj.getLetra(quien, clave);
                            System.out.print("letra="+letra.toUpperCase()+"\n");
                            for (String arrayCategoria : arrayCategorias) {
                                System.out.println("--" + arrayCategoria + "--");
                                String resultado = CSVReader.buscar(arrayCategoria, letra);
                                System.out.println(resultado);
                                String devolucion="";
                                devolucion=obj.setPalabra(resultado, quien, clave);
                                System.out.println(devolucion);
                                if(devolucion=="rpt"){
                                    //obj.getPalabra(quien, clave, categorias);
                                }
                                
                            }
                            //System.out.println(obj.setPalabra(letra, quien, clave));
                            String puntaje = obj.getMisPuntos(letra, quien);
                            System.out.println("  -  puntaje="+puntaje);
                        }
                        System.out.println(obj.getUltimoMensajeError(quien, clave));
                        System.out.println(obj.getGanador(quien, clave));
                        System.out.println("terminar comunicacion="+obj.terminarComunicacion(quien, clave));
                      } catch (Exception e) {
                                System.out.println("hubo un error");
                        } 
                }
            }
