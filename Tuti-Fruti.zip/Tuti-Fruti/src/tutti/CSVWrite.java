/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutti;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
//import com.csvreader.CsvWriter;
import au.com.bytecode.opencsv.CSVWriter;


/**
 *
 * @author Lino Rallo
 */
public class CSVWrite {

    public CSVWrite(FileWriter outputfile, Object par1) {
    }
    
    public static void escribirManualmente(){

        String file = "C:\\Users\\Lino Rallo\\Documents\\UTN\\Programacion Avanzada\\tutti\\Tuti-Fruti\\escribirManualmente.csv";
        FileWriter fileWriter = null;
        String COMMA_DELIMITER = ",";
        String NEW_LINE_SEPARATOR = "\r\n";
        String line ="";
        try(BufferedReader br = new BufferedReader(new FileReader(file))){
           // CsvWriter csvOutput = new CsvWriter(new FileWriter(file, true), ',');
            Scanner reader = new Scanner(System.in);
            String in = reader.next();
           fileWriter  = new FileWriter(file); 
           //while((line=br.readLine())==null){
               //fileWriter.append(in);
           //fileWriter.append(COMMA_DELIMITER);
           //fileWriter.append(NEW_LINE_SEPARATOR);
            //    csvOutput.write(in);
                //csvOutput.endRecord();
                //csvOutput.close();
                CSVWriter writer = new CSVWriter(new FileWriter(file, true));
        
      String [] record = in.split(",");
        
      writer.writeNext(record);
        
      writer.close();
             //   break;
           //}
           
        }catch(Exception e){
            System.out.println("Error en tutti.CSVWriter.escribir()");
        }finally{
            try{
                fileWriter.flush();
                fileWriter.close();
            }catch(IOException e){
                System.out.println("Error cerrando CSV en tutti.CSVWriter.escribir()");
            }
        }
    }
    public static void escribir(String categoria, String palabra) throws IOException{
        File file= new File("C:\\Users\\Lino Rallo\\Documents\\UTN\\Programacion Avanzada\\tutti\\Tuti-Fruti\\diccionarioAutomatico"+categoria+".csv");
        FileWriter fileWriter = null;
        String COMMA_DELIMITER = ",";
        String NEW_LINE_SEPARATOR = "\n";
        try{
           fileWriter  = new FileWriter(file); 
           fileWriter.append(COMMA_DELIMITER);
           fileWriter.append(palabra);
        }catch(Exception e){
            System.out.println("Error en tutti.CSVWriter.escribir()");
        }finally{
            try{
                fileWriter.flush();
                fileWriter.close();
            }catch(IOException e){
                System.out.println("Error cerrando CSV en tutti.CSVWriter.escribir()");
            }
        }
        
        
    }

    private CSVWrite(FileWriter outputfile) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
