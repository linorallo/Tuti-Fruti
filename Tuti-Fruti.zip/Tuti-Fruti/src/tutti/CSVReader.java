/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tutti;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


/**
 *
 * @author lino
 */
public class CSVReader {
    static CSVReader csv;
    
    public static String buscar(String categoria,String letra) throws IOException{
        String line = "";
        String resultado="vacio";
        String csvFile="C:\\Users\\Lino Rallo\\Documents\\UTN\\Programacion Avanzada\\tutti\\Tuti-Fruti\\diccionario"+categoria+".csv";
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
        
        while ((line=br.readLine())!=null) {
            if(line.startsWith(letra)){  
                 resultado=line;
                break;
            }else{
                if(line.startsWith(letra.toUpperCase())){
                    resultado=line;
                    System.out.println("Upper: "+resultado);
                    break;
                }else{
                    resultado="null";
                }
            }
           // return resultado;
        }
return resultado;
    }   catch (FileNotFoundException ex) {
            
        }
        return null;
}
}
        

